import numpy as np
import time

# A dictionary of possible arithmetic operations where the keys are the string representations of the oeprations
# and the values are the corresponding functions to perform the respective operations on two numbers
operations = {
    "+": lambda a, b: a + b,
    "-": lambda a, b: a - b,
    "*": lambda a, b: a * b,
    "//": lambda a, b: a // b
}

i = 0

def generate_question():
    """
    Function that randomly generates a new question for the arithmetic game.

    Returns
    -------
    question : str
        A string representation of the question (e.g. "10 + 5")
    result : int
        The correct answer to the question
    """
    operation = np.random.choice(list(operations.keys()))
    a, b = np.random.randint(1, 101, 2)

    return f"{a} {operation} {b}", operations[operation](a, b)


def ask_question():
    """
    Function that asks a question to the player, handles input and keeps track of time.

    Returns
    -------
    dt : float
        The time it took the player to answer (in seconds)
    """
    question_string, result = generate_question()
    
    global i
    i += 1 # Increment the question counter
    
    print(f"\nQuestion {i}: What is {question_string}?") # Ask the question to the player

    answer = None

    start_time = time.time() # Record the current time in order to comput the time it took the player to answer later

    while True:
        try:
            answer = int(input("> "))
            assert isinstance(answer, int) # The result must be an integer in any case
        except (ValueError, AssertionError):
            print("You must give an integer as an answer.")
        finally:
            dt = time.time() - start_time
            if dt > 10:
                raise TimeoutError(f"You took {dt:0.1f} seconds to answer, which is above the time limit of 10 seconds.")
            if answer != None:
                break # If the player gave an integer, we break from the loop

    if answer == result:
        return time.time() - start_time # Return the time it took the player to answer
    raise EOFError # We raise an EOFError to indicate a wrong answer
    