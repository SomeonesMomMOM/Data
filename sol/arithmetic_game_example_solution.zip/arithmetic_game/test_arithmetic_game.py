import pytest

import os
import time

from statsfile import Statsfile
from arithmetic_game import get_input
from game import generate_question

def test_statsfile_rejects_filename():
    """Test that checks whether the statsfile init function correctly rejects a statsfile
    name that belongs to an already existing file with non-JSON content
    """

    filename = f"test_statsfile_{time.time()}.txt" # Generate a random statsfile name
    with open(filename, "w") as file:
        file.write("Some content that is not of JSON format")

    try:
        Statsfile(filename)
        assert False, "No value error was raised on invalid statsfile content"
    except ValueError:
        pass
    finally:
        os.remove(filename) # Clean up the created test file


def test_generate_question():
    """Test that checks whether the generate_question function works and produces the correct result"""
    for _ in range(10):
        question, result = generate_question() # Generate 10 questions
        assert eval(question) == result # Check whether the string representation of the question evaluates to the returned result

def test_name_not_empty():
    """Test that checks whether the program exits on an empty name"""
    with pytest.raises(SystemExit):
        get_input({"--name": "", "--statsfile": ""})
    