"""Arithmetic game

Usage:
    arithmetic_game [(--name=<name> --statsfile=<statsfile>)]

Options:
    --name=<name>               Player name to use for the stats file.
    --statsfile=<statsfile>     Stats file name.

"""

import docopt
import numpy as np

from game import ask_question
from statsfile import Statsfile

import sys

def get_input(opts):
    """Helper function that gets the player name and the statsfile either from command line
    arguments or from user input.
    
    Parameters
    ----------
    opts : dict
        Dictionary of command line arguments

    Returns
    -------
    name : str
        Name of the player
    statsfile : Statsfile
        Statsfile object
    
    """
    statsfile = None

    if opts["--name"] != None and opts["--statsfile"] != None:
        # If command line options were given, evaluate them
        name = opts["--name"]
        filename = opts["--statsfile"]

        if len(name) == 0:
            print("You must give a non-empty name.")
            sys.exit(0) # Exit if the name was empty
        
        try:
            statsfile = Statsfile(filename)
        except ValueError as err:
            print(err)
            sys.exit(0) # Exit if there was an error with the stats file

    else:
        # If no command line options were given, ask the user for the required information

        name = ""
        # Ask the player for their name until they give one
        while len(name) == 0:
            try:
                name = input("Your name: ")
            except KeyboardInterrupt:
                return # End the program on a keyboard interrupt

        while True:
            try:
                filename = input("Stats file name: ")
            
                try:
                    statsfile = Statsfile(filename)
                    break
                except ValueError as err:
                    print(err)
            except KeyboardInterrupt:
                return # End the program on a keyboard interrupt
            
    return name, statsfile

def main(opts):

    name, statsfile = get_input(opts)

    score = 0
    times = [] # Keep track of the time the player takes to answer each question

    while True:
        try:
            times.append(ask_question()) # Append the time dt the player took to answer to the list
            score += 1 # Increase the player's current score
        except TimeoutError as err:
            print("")
            print(err)
            break # End the game if the time limit was exceeded
        except EOFError:
            print("\nWrong answer!")
            break # End the game on a wrong answer
        except KeyboardInterrupt:
            print("\nEnding game.")
            break

    print("\nYour Stats:")
    print(f"Score: {score}")
    if score > 0:
        average_time = np.mean(times) # Calculate average time per question
        print(f"Average time per question: {average_time:0.2f} seconds")

    highscore = statsfile.get_highscore(name)
    if highscore < score:
        print("\nCongratulations! New Highscore!")
        statsfile.set_highscore(name, score)

if __name__ == "__main__":
    main(docopt.docopt(__doc__))