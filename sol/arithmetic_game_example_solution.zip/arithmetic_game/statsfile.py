import json
import os

class Statsfile:
    """
    A class that manages keeping and changing statistics for the game

    Attributes
    ----------

    """

    def __init__(self, filename):
        """
        Init function for the Statsfile class.

        Parameters
        ----------
            filename : str
                The name of the stats file on the disk (file will be created if it does not exist)

        """
        self.filename = filename

    
    @property
    def filename(self):
        """
        Getter function for the filename instance variable

        Returns
        -------
        filename : str
            The name of the stats file
        """
        return self._filename
    
    @filename.setter
    def filename(self, value):
        """
        Setter function for the filename instance variable
        
        Parameters
        ----------
        value : str
            The new value for the stats file name
        """
        # Check for empty file name
        if len(value) == 0:
            raise ValueError("File name cannot be empty")
        
        # Check whether file exists and, if so, check whether its content is of JSON format
        # in order to avoid accidentally overwriting existing file
        if os.path.isfile(value):
            with open(value) as file:
                try:
                    json.load(file)
                except json.JSONDecodeError:
                    raise ValueError("Given file exists and content does not match json syntax")
        self._filename = value

    def _read_statsfile(self):
        """
        Function that reads the content of the stats file and returns it as a dictionary.
        If the statsfile is empty, it returns an empty dictionary.

        Returns
        -------
        content : dict
            The content of the statsfile
        """
        content = {}

        try:
            with open(self.filename, "r") as file:
                content = json.load(file)

        except FileNotFoundError:
            pass # If the file doesn't exist, we return an empty dictionary
        except json.JSONDecodeError:
            raise ValueError # If the file exists but the content is not JSON, we stop execution in order to avoid data loss
        return content

    def get_highscore(self, playername):
        """
        Function that retrieves the current highscore of a given player from the statsfile.
        If no high score exists, returns 0

        Parameters
        ----------
        playername : str
            The name of the player for which to retrieve the highscore

        Returns
        -------
        highscore : int
            The highscore of the given player, if the player is present in the statsfile
        0
            If the player is not in the statsfile
        """
        try:
            content = self._read_statsfile()
            if playername in content.keys():
                return content[playername]
            return 0
        except ValueError:
            return 0 # If there is a ValueError, we do not store stats for the session (see content of self._read_statsfile())
        
    def set_highscore(self, playername, value):
        """
        Function that sets the highscore for a player to a given value.

        Parameters
        ----------
        playername : str
            The name of the player for which to set the highscore
        value : int
            The number to set the highscore to
        """
        assert isinstance(value, int), "Given highscore value was not of type int"
        try:
            content = self._read_statsfile()
            content[playername] = value

            with open(self._filename, "w") as file:
                file.write(json.dumps(content))

            print(f"Stored highscore in {self.filename}")
        
        except ValueError:
            # We do not overwrite the statsfile if it exists and its content is not of json format
            print(f"Stats file {self.filename} has been created or modified since the start of the game and was filled with non-JSON content. Not recording stats for this session.")