import numpy as np
from matplotlib import pyplot as plt
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter, AutoMinorLocator, AutoLocator)
import sys
import os

class DataSetLoader:
    """Class that represents a data set loader, which loads the contents of a given file containing n
    data points (X_i, Y_i).

    Parameters
    ----------
    filename : str
        Name of the file to load the data from

    """

    def __init__(self, filename):
        self.filename = filename

    @property
    def filename(self):
        """Getter for the self._filename variable

        Returns
        -------
        self._filename : str
            The name of the data file
        """
        return self._filename

    @filename.setter
    def filename(self, value):
        """Setter for the self._filename variable. Checks for existence and
        the immediately loads given file into self.data

        Parameters
        ----------
        value : str
            The new file name to load data from
        """
        if not os.path.isfile(value):
            raise ValueError(f"File {value} does not exist")

        self._filename = value
        self.load_data()

    def load_data(self):
        """Load the data from file self.filename, assuming comma-separated values"""
        self.data = np.loadtxt(self.filename, delimiter=",")

    def linregress(self):
        """Function that performs linear regression on the data, i.e., the function fits the
        data to the function
            f(x) = a*x + b

        Returns
        -------
        a : float
            Slope of the fit

        b : float
            y-intercept of the fit
        """
        X = self.data[:, 0]
        Y = self.data[:, 1]
        n = self.data.shape[0]

        sum_x = np.sum(X) # Sum of all X_i
        sum_y = np.sum(Y) # Sum of all Y_i
        sum_xy = np.sum(X*Y) # Sum of X_i * Y_i
        sum_x2 = np.sum(X**2) # Sum of X_i^2
        
        a = (n * sum_xy - sum_x*sum_y)/(n * sum_x2 - sum_x**2)
        b = (sum_y - a * sum_x)/n

        return a, b

def plot_fit(data, a, b):
    """Function that plots the result of a linear fit

    Parameters
    ----------
    data : np.ndarray
        The data set containing the points (X_i, Y_i), loaded through DataSetLoader

    a : float
        The slope of the linear fit

    b : float
        The y-intercection of the fit
    """

    fig, ax = plt.subplots(1, 1)

    # Make sure the grid is below the plot
    ax.set_axisbelow(True)

    # Add grid to the plot (optional, just for looks)
    ax.grid(visible=True, which="both")
    ax.xaxis.set_minor_locator(AutoMinorLocator())
    ax.xaxis.set_major_locator(AutoLocator())
    ax.yaxis.set_minor_locator(AutoMinorLocator())
    ax.yaxis.set_major_locator(AutoLocator())
    ax.tick_params(which='both', width=1)
    ax.tick_params(which='major', length=7)
    ax.tick_params(which='minor', length=4, grid_linestyle="--", grid_color="lightgray")

    # Plot data set
    ax.scatter(data[:, 0], data[:, 1], label="Data points")
    
    # Prepare fit function
    f = lambda x: a*x + b
    x = np.array([0, np.max(data[:, 0])], dtype=float)

    # Plot fit
    ax.plot(x, f(x), color="red", label="Fit")

    # Labels
    ax.set_xlabel("$X_i$")
    ax.set_ylabel("$Y_i$")

    ax.legend()

    plt.show()


def main():
    """Main function, gets user input, fits data and plots the fit"""
    loader = None
    
    while loader == None:
        filename = input("Filename to read data from: ")
        try:
            loader = DataSetLoader(filename)
        except ValueError as err:
            print(err)
    
    a, b = loader.linregress()

    print(f"\nResults:")
    print(f"a = {a}")
    print(f"b = {b}\n")

    plot = None
    while True:
        result = input("Plot fit? [Y/n]: ").lower()
        if result not in ["", "y", "n"]:
            print("Please type either y or n")
            continue
        plot = result in ["", "y"]
        break

    if plot:
        plot_fit(loader.data, a, b)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Exiting program...")
        sys.exit(0)
