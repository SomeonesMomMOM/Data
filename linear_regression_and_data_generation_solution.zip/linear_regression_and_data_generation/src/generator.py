"""generator.py - Generate random noisy experimental data with linear dependence

Usage:
    generator.py
    generator.py -n=<n> --x_max=<x_max> [-a=<a> -b=<b>] [--plot] <filename>

Options:
    -n=<n>              The number of data points to generate.
    --x_max=<x_max>     The maximum x value.
    -a=<a>              The slope of the line [default: 1].
    -b=<b>              The y-axis intersect of the line [default: 0].
    --plot              Plot the generated data.
"""

import docopt
import numpy as np
from matplotlib import pyplot as plt
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter, AutoMinorLocator, AutoLocator)

def get_user_input(message, dtype, input_checks={}, default=None):
    """Helper function to get user input

    Parameters
    ----------
    message : str
        The message to prompt the user with

    dtype : Data type
        The data type expected from the user (will try to cast the
        input to this data type. If it succeeds, the result is
        returned, if not, the user is asked again)

    input_checks : dict
        Dictionary where the keys are functions that perform checks
        on the given input and return False if it was illegal. The
        values are the respective messages shown to the user if the
        check failed. Example:

        {(lambda x: x > 0) : "The value must be greater than 0"}

    default : dtype
        The default value to use if the user gives an empty input.
        Set to None to always require input or to allow empty string
        input.
    
    Returns
    -------
    result : dtype
        The result received from the user

    """
    while True:
        result = input(message)
        
        # If the user didn't give any input, use default if set
        if len(result) == 0 and default != None:
            return default
        
        # Try to cast given input to desired data type
        try:
            result = dtype(result)
        except ValueError:
            # Input could not be cast to dtype, ask again
            print(f"Expected input of type {dtype.__name__}")
            continue
        
        # Perform all the given input checks and print the respective error message if one fails
        failed = False
        for check, error_message in input_checks.items():
            if not check(result):
                print(error_message)
                failed = True
                break
        if failed:
            continue
        
        return result

def generate_data(n, x_max, a, b):
    """Function that generates n data points (X_i, Y_i) where 
    
        X_(i) - X_(i - 1) = x_max/n = const. (equally spaced)

    and there is a linear dependence of Y_i on X_i with slope a and
    y-intercept b, with added Gaussian noise.

    Parameters
    ----------
    n : int
        The number of data points (X_i, Y_i) to generate

    x_max : float
        The maximum x value

    a : float
        The slope of the linear function

    b : float
        The y-intercept of the linear function

    Returns
    -------
    data : np.ndarray
        The (X_i, Y_i) in matrix form, where the first column
        corresponds to the X_i and the second column to the Y_i

    """
    # Initialize empty array
    data = np.zeros((n, 2))

    # Generate the X_i
    data[:, 0] = np.linspace(0, x_max, n)

    # Generate the Y_i with Gaussian noise, where the mean of Y_i is a*X_i + b and the
    # standard deviation is 0.5
    data[:, 1] = np.random.normal(data[:, 0]*a + b, 0.5)

    return data

def plot_data(data):
    """Function that plots resulting data
    
    Parameters
    ----------
    data : np.ndarray
        Data points (X_i, Y_i) to be plotted

    """
    fig, ax = plt.subplots(1, 1)

    # Make sure the grid is below the plot
    ax.set_axisbelow(True)

    # Add grid to the plot (optional, just for looks)
    ax.grid(visible=True, which="both")
    ax.xaxis.set_minor_locator(AutoMinorLocator())
    ax.xaxis.set_major_locator(AutoLocator())
    ax.yaxis.set_minor_locator(AutoMinorLocator())
    ax.yaxis.set_major_locator(AutoLocator())
    ax.tick_params(which='both', width=1)
    ax.tick_params(which='major', length=7)
    ax.tick_params(which='minor', length=4, grid_linestyle="--", grid_color="lightgray")

    # Plot data
    ax.scatter(data[:, 0], data[:, 1])

    # Labels
    ax.set_xlabel("$X_i$")
    ax.set_ylabel("$Y_i$")

    plt.show()


def main(opts=None):
    """Main function, handles user input and command line arguments

    Parameters
    ----------
    opts : dict
        Dictionary from docopt containing the command line arguments, if none, input()
        is used to get required info.

    """
    
    n = None
    x_max = None
    a = None
    b = None
    filename = None
    plot = None

    if opts == None or opts["-n"] == None:
        # If this is the case, we get the info from the user through input statements
        # Here, I use my helper function to greatly reduce the amount of code I need to
        # write and to improve readability
        n = get_user_input("Number of data points (n): ", int, 
                           {lambda x: x > 0 : "n must be at least 1"})
        x_max = get_user_input("Maximum x-value (x_max): ", float, 
                               {lambda x: x > 0 : "x_max must be greater than 0"})
        a = get_user_input("Slope (a) [1.0]: ", float, default=1.0)
        b = get_user_input("Intersection with y-axis (b) [0.0]: ", float, default=0.0)
        filename = get_user_input("Filename to write results to [results.csv]: ", str, default="results.csv")
    else:
        try:
            n = int(opts["-n"])
            x_max = float(opts["--x_max"])
            a = float(opts["-a"])
            b = float(opts["-b"])
            filename = opts["<filename>"]
            plot = opts["--plot"]

            # Perform sanity checks
            assert n > 0, "n must be at least 1"
            assert x_max > 0, "x_max must be greater than 0"
        except ValueError:
            # The user gave input of invalid data type
            print("Correct data types:")
            print("n : int")
            print("x_max : float")
            print("a : float")
            print("b : float")
            return
        except AssertionError as err:
            # The user gave value that did not pass sanity checks
            print(err)
            return

    # Generate the data
    data = generate_data(n, x_max, a, b)

    # Write to file with appropriate delimiter
    np.savetxt(filename, data, delimiter=",")
    print(f"\nSaved results to {filename}")
    
    # plot will be None if the program did not get any command line arguments
    # through docopt
    if plot == None:
        # Ask user if they want to show plot
        plot = get_user_input("Plot result? [Y/n]: ", str, 
                            {lambda x: x.lower() in ["y", "n"] : "Type either y or n"},
                            default="y").lower() == "y"
    if plot:
        plot_data(data)

if __name__ == "__main__":
    opts = docopt.docopt(__doc__)
    try:
        main(opts)
    except KeyboardInterrupt:
        print("Exiting program...")
        sys.exit(0)
